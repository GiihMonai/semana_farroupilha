<?php
require_once "conexao.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)$_POST['id'];
    $titulo     = $conexao->real_escape_string($_POST['titulo']);
    $genero     = $conexao->real_escape_string($_POST['genero']);
    $plataforma = $conexao->real_escape_string($_POST['plataforma']);
    $ano        = (int)$_POST['ano'];
    $nota       = (float)$_POST['nota'];
    $zerado     = (int)$_POST['zerado'];

    $sql = "UPDATE jogos SET 
            titulo = '$titulo', 
            genero = '$genero', 
            plataforma = '$plataforma', 
            ano = $ano, 
            nota = $nota, 
            zerado = $zerado 
            WHERE id = $id";

    if ($conexao->query($sql)) {
        echo "<p>Jogo atualizado com sucesso!</p>";
    } else {
        echo "<p>Erro ao atualizar: " . $conexao->error . "</p>";
    }
}
?>
<a href="listar.php">Voltar para a lista de jogos</a>