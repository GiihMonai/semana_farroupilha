<?php
require_once "conexao.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $sql = "DELETE FROM jogos WHERE id = $id";
    
    if ($conexao->query($sql)) {
        echo "<p>Jogo excluído com sucesso!</p>";
    } else {
        echo "<p>Erro ao excluir: " . $conexao->error . "</p>";
    }
}
?>
<a href="listar.php">Voltar para a lista de jogos</a>