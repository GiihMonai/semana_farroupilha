<?php
require_once "conexao.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo     = $conexao->real_escape_string($_POST['titulo']);
    $genero     = $conexao->real_escape_string($_POST['genero']);
    $plataforma = $conexao->real_escape_string($_POST['plataforma']);
    $ano        = (int)$_POST['ano'];
    $nota       = (float)$_POST['nota'];
    $zerado     = (int)$_POST['zerado'];

    $sql = "INSERT INTO jogos (titulo, genero, plataforma, ano, nota, zerado) 
            VALUES ('$titulo', '$genero', '$plataforma', $ano, $nota, $zerado)";

    if ($conexao->query($sql)) {
        echo "<p>Jogo cadastrado com sucesso!</p>";
    } else {
        echo "<p>Erro ao cadastrar: " . $conexao->error . "</p>";
    }
}
?>
<a href="listar.php">Voltar para a lista de jogos</a>