<?php
session_start();

if (isset($_POST['nome_jogador'])) {
    $_SESSION['nome_jogador'] = $_POST['nome_jogador'];
}

$nome = $_SESSION['nome_jogador'] ?? 'Vivente';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz CTG - Desafio Farroupilha</title>
    <style>
        :root {
            --sunshine: #ffc926;
            --cream: #f3e8cc;
            --forest-green: #18542a;
            --tomato-burst: #d52518;
        }

        body {
            background-color: var(--forest-green); 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--forest-green);
            margin: 0;
            padding: 20px;
            transition: background-color 0.5s ease; 
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 20px;
        }

        header {
            text-align: center;
            border-bottom: 4px solid var(--sunshine);
            margin-bottom: 40px;
            padding-bottom: 20px;
        }

        h1 { color: var(--tomato-burst); margin: 0; }

        .pergunta-card {
            margin-bottom: 35px;
            padding: 20px;
            background: #fafafa;
            border-left: 6px solid var(--forest-green);
            border-radius: 4px;
        }

        .pergunta-titulo { font-weight: bold; font-size: 1.1rem; display: block; margin-bottom: 15px; }

        .opcao {
            display: block;
            background: white;
            border: 2px solid #eee;
            margin: 10px 0;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
        }

        .opcao:hover { border-color: var(--sunshine); background: var(--cream); }

        input[type="radio"] { margin-right: 12px; accent-color: var(--tomato-burst); }

        .btn-enviar {
            background-color: var(--forest-green);
            color: var(--sunshine);
            border: none;
            width: 100%;
            padding: 20px;
            font-size: 1.4rem;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            text-transform: uppercase;
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>Quiz do CTG</h1>
        <p>Bem-vindo ao galpão, <strong><?php echo htmlspecialchars($nome); ?></strong>! Boa sorte no desafio.</p>
    </header>

    <form action="resultado.php" method="POST">
        
        <div class="pergunta-card">
            <span class="pergunta-titulo">1. Qual era o principal caráter ideológico da Revolução Farroupilha em relação ao governo imperial?</span>
            <label class="opcao"><input type="radio" name="p1" value="0" required> Monarquista</label>
            <label class="opcao"><input type="radio" name="p1" value="1"> Republicano</label>
            <label class="opcao"><input type="radio" name="p1" value="0"> Ditatorial</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">2. Em qual província brasileira teve início a Guerra dos Farrapos?</span>
            <label class="opcao"><input type="radio" name="p2" value="0" required> Santa Catarina</label>
            <label class="opcao"><input type="radio" name="p2" value="1"> São Pedro do Rio Grande do Sul</label>
            <label class="opcao"><input type="radio" name="p2" value="0"> São Paulo</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">3. Quem foi um dos principais líderes militares da revolução?</span>
            <label class="opcao"><input type="radio" name="p3" value="1" required> Bento Gonçalves da Silva</label>
            <label class="opcao"><input type="radio" name="p3" value="0"> Bento Manuel Ribeiro</label>
            <label class="opcao"><input type="radio" name="p3" value="0"> Luigi Rossetti</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">4. Além do RS, em qual outra região a revolução se expandiu, proclamando a República Juliana?</span>
            <label class="opcao"><input type="radio" name="p4" value="1" required> Laguna</label>
            <label class="opcao"><input type="radio" name="p4" value="0"> Corrientes</label>
            <label class="opcao"><input type="radio" name="p4" value="0"> Lages</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">5. Sobre a questão da escravidão na Guerra dos Farrapos:</span>
            <label class="opcao"><input type="radio" name="p5" value="0" required> Os líderes eram abolicionistas convictos</label>
            <label class="opcao"><input type="radio" name="p5" value="0"> A escravidão foi abolida imediatamente</label>
            <label class="opcao"><input type="radio" name="p5" value="1"> Homens negros lutaram nos exércitos visando a liberdade</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">6. Qual o significado da cor vermelha ter sido entrecortada entre o verde e o amarelo na bandeira?</span>
            <label class="opcao"><input type="radio" name="p6" value="0" required> Representava as matas dos pampas gaúchos</label>
            <label class="opcao"><input type="radio" name="p6" value="1"> Simbolizava o ideal republicano e revolucionário</label>
            <label class="opcao"><input type="radio" name="p6" value="0"> Referia-se à cor oficial da bandeira espanhola</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">7. Qual o nome da dança tradicional que é um animal típico do Rio Grande do Sul?</span>
            <label class="opcao"><input type="radio" name="p7" value="1" required> Maçanico</label>
            <label class="opcao"><input type="radio" name="p7" value="0"> Quero-quero</label>
            <label class="opcao"><input type="radio" name="p7" value="0"> Bugio</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">8. Qual é o compasso mais utilizado para dançar chula?</span>
            <label class="opcao"><input type="radio" name="p8" value="1" required> 8</label>
            <label class="opcao"><input type="radio" name="p8" value="0"> 12</label>
            <label class="opcao"><input type="radio" name="p8" value="0"> 347</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">9. Qual é a ordem das invernadas dentro de um CTG?</span>
            <label class="opcao"><input type="radio" name="p9" value="0" required> Berçário, Maternal, Juvenil, Adulta, Veterana, Ancião</label>
            <label class="opcao"><input type="radio" name="p9" value="1"> Dente de leite, Mirim, Juvenil, Adulta, Veterana, Xiru</label>
            <label class="opcao"><input type="radio" name="p9" value="0"> Pré-Mirim, Mirim, Jovial, Adulta, Veterana</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">10. Existe dentro das danças tradicionais gaúchas 4 tipos de ciclos coreográficos, qual desses NÃO é um?</span>
            <label class="opcao"><input type="radio" name="p10" value="0" required> Ciclo do fandango</label>
            <label class="opcao"><input type="radio" name="p10" value="0"> Ciclo das contradanças</label>
            <label class="opcao"><input type="radio" name="p10" value="1"> Ciclo dos sapateios</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">11. Qual a principal característica do “ciclo dos pares enlaçados”?</span>
            <label class="opcao"><input type="radio" name="p11" value="1" required> Alegre e envolvente</label>
            <label class="opcao"><input type="radio" name="p11" value="0"> Vivo, alegre e descontraído</label>
            <label class="opcao"><input type="radio" name="p11" value="0"> Exibicionismo</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">12. Qual a mão que é utilizada para convidar a prenda para dançar?</span>
            <label class="opcao"><input type="radio" name="p12" value="1" required> Mão direita</label>
            <label class="opcao"><input type="radio" name="p12" value="0"> Mão esquerda</label>
            <label class="opcao"><input type="radio" name="p12" value="0"> Ela que vá sozinha</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">13. Existem 3 tipos de “harmonia de conjunto das danças”, isso é, como vão ser as posições de cada par na dança. Qual entre as abaixo NÃO é uma opção?</span>
            <label class="opcao"><input type="radio" name="p13" value="0" required> Dança de fila</label>
            <label class="opcao"><input type="radio" name="p13" value="0"> Dança de roda</label>
            <label class="opcao"><input type="radio" name="p13" value="1"> Dança individual</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">14. Hoje em dia, o charque é salgado com sal grosso e depois deixado ao sol para ficar pronto, mas os tropeiros em suas longas viagens salgavam a carne de outra forma. Como era feito?</span>
            <label class="opcao"><input type="radio" name="p14" value="0" required> Temperos exóticos</label>
            <label class="opcao"><input type="radio" name="p14" value="1"> Suor de cavalo</label>
            <label class="opcao"><input type="radio" name="p14" value="0"> Sal do Himalaia</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">15. Na versão mais popular da lenda do Negrinho do Pastoreio, quem é a figura que aparece para proteger o Negrinho após ele ser castigado no formigueiro?</span>
            <label class="opcao"><input type="radio" name="p15" value="0" required> A mãe do menino, que era uma escrava fugitiva</label>
            <label class="opcao"><input type="radio" name="p15" value="1"> A Virgem Maria, considerada sua madrinha</label>
            <label class="opcao"><input type="radio" name="p15" value="0"> O filho do estancieiro, que era seu amigo secreto</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">16. Segundo a lenda da Erva-Mate, qual foi o pedido feito pelo velho guerreiro ao mensageiro de Tupã para que sua filha, Yari, pudesse ser livre?</span>
            <label class="opcao"><input type="radio" name="p16" value="0" required> Que o mensageiro levasse Yari para conhecer outras tribos e encontrar um marido</label>
            <label class="opcao"><input type="radio" name="p16" value="0"> Que ele recebesse riquezas e sementes para que nunca mais passassem fome</label>
            <label class="opcao"><input type="radio" name="p16" value="1"> Que suas forças fossem devolvidas para que a filha não precisasse mais cuidar dele</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">17. Qual o nome correto do CTG ao qual o aluno Lorenzo Baldasso Vicente participa?</span>
            <label class="opcao"><input type="radio" name="p17" value="0" required> Estância do Rio Grande</label>
            <label class="opcao"><input type="radio" name="p17" value="1"> Tropeiro da Serra</label>
            <label class="opcao"><input type="radio" name="p17" value="0"> Lanceiros</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">18. Qual o principal criador do movimento tradicionalista gaúcho moderno?</span>
            <label class="opcao"><input type="radio" name="p18" value="0" required> Lorenzo Baldasso Vicente</label>
            <label class="opcao"><input type="radio" name="p18" value="0"> Gilberto Bitencourt</label>
            <label class="opcao"><input type="radio" name="p18" value="1"> Paixão Côrtes</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">19. Qual a música gaúcha mais ouvida (2026)?</span>
            <label class="opcao"><input type="radio" name="p19" value="1" required> Querência Amada</label>
            <label class="opcao"><input type="radio" name="p19" value="0"> Céu, Sol, Sul, Terra e Cor</label>
            <label class="opcao"><input type="radio" name="p19" value="0"> Tordilho Negro</label>
        </div>

        <div class="pergunta-card">
            <span class="pergunta-titulo">20. Qual o cantor tradicionalista gaúcho mais ouvido (2026)?</span>
            <label class="opcao"><input type="radio" name="p20" value="0" required> Baitaca</label>
            <label class="opcao"><input type="radio" name="p20" value="0"> Teixeirinha</label>
            <label class="opcao"><input type="radio" name="p20" value="1"> Luis Marenco</label>
        </div>

        <button type="submit" class="btn-enviar">Finalizar Quiz</button>
    </form>
</div>

<script>
window.onscroll = function() {
    const scrollMax = document.documentElement.scrollHeight - window.innerHeight;
    const scrolled = (window.scrollY / scrollMax) * 100;

    const green = getComputedStyle(document.documentElement).getPropertyValue('--forest-green');
    const red = getComputedStyle(document.documentElement).getPropertyValue('--tomato-burst');
    const yellow = getComputedStyle(document.documentElement).getPropertyValue('--sunshine');

    if (scrolled < 33) {
        document.body.style.backgroundColor = green;
    } else if (scrolled >= 33 && scrolled < 66) {
        document.body.style.backgroundColor = red;
    } else {
        document.body.style.backgroundColor = yellow;
    }
};
</script>

</body>
</html>