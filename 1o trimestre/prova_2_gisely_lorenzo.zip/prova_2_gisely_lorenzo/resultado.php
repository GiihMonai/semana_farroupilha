<?php
session_start();
$nome = $_SESSION['nome_jogador'] ?? 'Vivente';

$total_perguntas = 20;
$pontos = 0;

for ($i = 1; $i <= $total_perguntas; $i++) {
    if (isset($_POST["p$i"]) && $_POST["p$i"] == "1") {
        $pontos++;
    }
}

if ($pontos >= 18) {
    $mensagem = "Bah, mas que baita gaúcho! Tu conhece tudo dessa terra!";
    $cor_mensagem = "#18542a";
} elseif ($pontos >= 12) {
    $mensagem = "Muito bom, vivente! Tens o Rio Grande no coração.";
    $cor_mensagem = "#ffc926"; 
} else {
    $mensagem = "Precisa frequentar mais o galpão e tomar mais um mate pra aprender!";
    $cor_mensagem = "#d52518"; 
}

$questoes_resumo = [
    1 => "Caráter ideológico da Rev. Farroupilha",
    2 => "Província de início da Guerra",
    3 => "Líder militar principal",
    4 => "Região da República Juliana",
    5 => "Questão da escravidão",
    6 => "Significado da cor vermelha",
    7 => "Dança com nome de animal",
    8 => "Compasso da chula",
    9 => "Ordem das invernadas",
    10 => "O que NÃO é ciclo coreográfico",
    11 => "Ciclo dos pares enlaçados",
    12 => "Mão para convidar a prenda",
    13 => "O que NÃO é harmonia de conjunto",
    14 => "Como salgavam a carne",
    15 => "Proteção ao Negrinho do Pastoreio",
    16 => "Pedido na lenda da Erva-Mate",
    17 => "CTG do Lorenzo Baldasso",
    18 => "Criador do tradicionalismo moderno",
    19 => "Música mais ouvida (2026)",
    20 => "Cantor mais ouvido (2026)"
];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado - Quiz CTG</title>
    <style>
        :root {
            --sunshine: #ffc926;
            --cream: #f3e8cc;
            --forest-green: #18542a;
            --tomato-burst: #d52518;
            --correct: #2e7d32;
            --wrong: #c62828;
        }

        body {
            background-color: var(--cream);
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .card-resultado {
            background: white;
            padding: 30px;
            border-radius: 20px;
            width: 100%;
            max-width: 600px;
            text-align: center;
            border-top: 15px solid var(--forest-green);
            margin-bottom: 20px;
        }

        .score-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: var(--forest-green);
            color: var(--sunshine);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: 20px auto;
            border: 5px solid var(--sunshine);
        }

        .score-num { font-size: 2.5rem; font-weight: bold; }
        .score-total { font-size: 0.9rem; }

        .mensagem-box {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 10px;
            border-left: 8px solid <?php echo $cor_mensagem; ?>;
            margin: 20px 0;
            font-style: italic;
            color: #333;
        }

        .revisao-lista {
            width: 100%;
            max-width: 600px;
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-sizing: border-box;
        }

        .item-revisao {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .item-revisao:last-child { border-bottom: none; }

        .status-badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
            font-weight: bold;
            text-transform: uppercase;
        }

        .acertou { background: #e8f5e9; color: var(--correct); }
        .errou { background: #ffebee; color: var(--wrong); }

        .btn-reiniciar {
            display: block;
            background: var(--forest-green);
            color: var(--sunshine);
            text-decoration: none;
            padding: 15px;
            border-radius: 10px;
            font-weight: bold;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="card-resultado">
        <h1>Resultado do Quiz</h1>
        <p>Bom trabalho, <strong><?php echo htmlspecialchars($nome); ?></strong>!</p>

        <div class="score-circle">
            <span class="score-num"><?php echo $pontos; ?></span>
            <span class="score-total">de 20</span>
        </div>

        <div class="mensagem-box">
            "<?php echo $mensagem; ?>"
        </div>
    </div>

    <div class="revisao-lista">
        <h3>Revisão das Questões</h3>
        <?php foreach ($questoes_resumo as $num => $titulo): 
            $acertou = (isset($_POST["p$num"]) && $_POST["p$num"] == "1");
        ?>
            <div class="item-revisao">
                <span style="font-size: 0.95rem;"><?php echo $num . ". " . $titulo; ?></span>
                <span class="status-badge <?php echo $acertou ? 'acertou' : 'errou'; ?>">
                    <?php echo $acertou ? '✓ Correta' : '✗ Errada'; ?>
                </span>
            </div>
        <?php endforeach; ?>

        <a href="index.php" class="btn-reiniciar">Tentar Novamente</a>
    </div>

</body>
</html>